export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { customer, shippingAddress, lineItems, discount, advanceDiscount, shippingFee, shippingTitle, paymentMethod, deliveryType, note } = req.body;

    if (!customer?.firstName || !customer?.phone || !shippingAddress?.city || !lineItems?.length) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const shopifyLineItems = lineItems.map(item => {
      const li = { title: item.name, price: String(item.price), quantity: item.quantity };
      if (item.variantId && item.variantId > 0) li.variant_id = item.variantId;
      return li;
    });

    const totalDisc = (discount || 0) + (advanceDiscount || 0);

    const draftOrderPayload = {
      draft_order: {
        line_items: shopifyLineItems,
        shipping_address: {
          first_name: shippingAddress.firstName,
          last_name:  shippingAddress.lastName  || '',
          address1:   shippingAddress.address1,
          address2:   shippingAddress.address2  || '',
          city:       shippingAddress.city,
          province:   shippingAddress.province  || '',
          zip:        shippingAddress.zip        || '',
          country:    shippingAddress.country    || 'PK',
          phone:      shippingAddress.phone,
        },
        email: customer.email || '',
        phone: customer.phone,
        note:  note || '',
        tags:  `osiss-custom, ${paymentMethod || 'cod'}`,
        shipping_line: {
          title: shippingTitle || 'Economy Delivery',
          price: String(shippingFee || 0),
          code:  deliveryType || 'economy',
        },
        ...(totalDisc > 0 ? {
          applied_discount: {
            description: 'Discount',
            value_type:  'fixed_amount',
            value:       String(totalDisc),
            amount:      String(totalDisc),
          }
        } : {}),
      }
    };

    const shopifyRes = await fetch(
      `https://${process.env.SHOPIFY_STORE_DOMAIN}/admin/api/2024-01/draft_orders.json`,
      {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'X-Shopify-Access-Token': process.env.SHOPIFY_ACCESS_TOKEN },
        body: JSON.stringify(draftOrderPayload),
      }
    );

    const shopifyData = await shopifyRes.json();
    if (!shopifyRes.ok) {
      return res.status(shopifyRes.status).json({ error: 'Shopify error', details: shopifyData.errors });
    }

    const d = shopifyData.draft_order;
    // Return format osiss.js expects: result.id, result.name, result.invoice_url
    return res.status(200).json({ id: d.id, name: d.name, invoice_url: d.invoice_url || '' });

  } catch (err) {
    console.error('Proxy error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
