/* ============================================================
   OSISS — Vercel Proxy Order Integration
   
   YEH CODE osiss.js mein dhoondho:
   "submitCODOrder" ya jahan COD form submit hota hai
   aur us function ko replace karo is se.
   ============================================================ */

// ── CONFIG — Apna Vercel URL yahan daalo ──────────────────────
const OSISS_PROXY_URL = 'https://YOUR-PROJECT.vercel.app/api/create-order';
// Example: 'https://osiss-proxy.vercel.app/api/create-order'

// ── MAIN ORDER SUBMIT FUNCTION ────────────────────────────────
// Yeh function COD form submit pe call karo
async function submitOsissOrder() {
  const btn = document.getElementById('codSubmitBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'PLACING ORDER...'; }

  try {
    // Form fields se data lo
    const firstName = document.getElementById('f-fname')?.value?.trim() || '';
    const lastName  = document.getElementById('f-lname')?.value?.trim() || '';
    const email     = document.getElementById('f-email')?.value?.trim() || '';
    const phone     = document.getElementById('f-phone')?.value?.trim() || '';
    const address1  = document.getElementById('f-addr1')?.value?.trim() || '';
    const address2  = document.getElementById('f-addr2')?.value?.trim() || '';
    const city      = document.getElementById('f-city')?.value?.trim() || '';
    const province  = document.getElementById('f-province')?.value?.trim() || '';
    const zip       = document.getElementById('f-postal')?.value?.trim() || '';
    const country   = document.getElementById('f-country')?.value || 'PK';

    // Payment method
    const selectedPay = document.querySelector('.pay-opt.selected');
    const paymentMethod = selectedPay?.dataset?.pay || 'cod';

    // Delivery type
    const selectedDel = document.querySelector('.delivery-opt.selected');
    const deliveryType = selectedDel?.dataset?.delivery || 'economy';

    // Promo code
    const promoCode = document.getElementById('promoInput')?.value?.trim() || '';

    // Validation
    if (!firstName || !phone || !address1 || !city) {
      showOrderError('Please fill all required fields.');
      if (btn) { btn.disabled = false; btn.textContent = 'PLACE ORDER'; }
      return;
    }
    if (phone.replace(/\D/g,'').length < 11) {
      showOrderError('Please enter a valid phone number.');
      if (btn) { btn.disabled = false; btn.textContent = 'PLACE ORDER'; }
      return;
    }

    // Cart items — Shopify variant IDs zaroori hain
    // cart = global array from osiss.js
    const items = cart.map(item => ({
      variantId: item.shopifyVariantId || item.id, // Shopify variant ID
      title: item.name,
      price: item.price * 100, // PKR to paisa (100 = PKR 1)
      quantity: item.qty,
    }));

    if (!items.length) {
      showOrderError('Cart is empty!');
      if (btn) { btn.disabled = false; btn.textContent = 'PLACE ORDER'; }
      return;
    }

    // API call to Vercel proxy
    const response = await fetch(OSISS_PROXY_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        firstName, lastName, email, phone,
        address1, address2, city, province, zip, country,
        paymentMethod, deliveryType, promoCode,
        items,
      }),
    });

    const result = await response.json();

    if (result.success) {
      // ✅ Order placed! 
      showOrderSuccess(result.orderNumber);
      cart = []; // Clear cart
      updateCartCount();
      
      // Close modal after 3 seconds
      setTimeout(() => { closeCheckout(); }, 3000);
    } else {
      showOrderError('Order failed: ' + (result.error || 'Please try again.'));
      if (btn) { btn.disabled = false; btn.textContent = 'PLACE ORDER'; }
    }

  } catch (err) {
    console.error('Order error:', err);
    showOrderError('Network error. Please check connection and try again.');
    if (btn) { btn.disabled = false; btn.textContent = 'PLACE ORDER'; }
  }
}

// ── SUCCESS MESSAGE ────────────────────────────────────────────
function showOrderSuccess(orderNumber) {
  const body = document.getElementById('modalBody');
  if (!body) return;
  body.innerHTML = `
    <div style="text-align:center;padding:40px 20px">
      <div style="font-size:48px;margin-bottom:16px">✅</div>
      <p style="font-size:14px;font-weight:900;letter-spacing:1px;margin-bottom:8px">ORDER PLACED!</p>
      <p style="font-size:20px;font-weight:900;color:#2d6a4f;margin-bottom:12px">${orderNumber}</p>
      <p style="font-size:11px;color:#666;line-height:1.6">
        Aapka order receive ho gaya hai.<br>
        Hamare team 30 minutes mein confirm karega.
      </p>
    </div>`;
}

// ── ERROR MESSAGE ──────────────────────────────────────────────
function showOrderError(msg) {
  const errEl = document.getElementById('orderError');
  if (errEl) {
    errEl.textContent = msg;
    errEl.style.display = 'block';
  } else {
    alert(msg);
  }
}

/* ============================================================
   SHOPIFY VARIANT IDs — IMPORTANT!
   
   Aapke products ke real Shopify Variant IDs chahiye.
   Yeh karo:
   
   1. Shopify Admin → Products → koi product open karo
   2. URL mein number dekho: /products/1234567890
   3. Ya Variants section mein "..." → "Copy variant ID"
   
   Phir PRODUCTS array mein add karo:
   
   { 
     id: 'OSS-HAIR-OIL', 
     shopifyVariantId: '12345678901234',  // ← YEH ADD KARO
     name: 'OSISS All-In-One Herbal Hair Oil',
     ...
   }
   ============================================================ */
