// ============================================================
// OSISS Shopify Draft Order Proxy
// Vercel Serverless Function
// ============================================================

export default async function handler(req, res) {
  // CORS headers — allow your Shopify store
  res.setHeader('Access-Control-Allow-Origin', 'https://osiss-7178.myshopify.com');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const {
      firstName, lastName, email, phone,
      address1, address2, city, province, zip, country,
      paymentMethod, deliveryType, promoCode,
      items, // [{ variantId, title, price, quantity }]
      note
    } = req.body;

    // Validate required fields
    if (!firstName || !phone || !address1 || !city || !items?.length) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Build line items for Shopify
    const lineItems = items.map(item => {
      const lineItem = {
        title: item.title,
        price: (item.price / 100).toFixed(2), // Convert paisa to PKR string
        quantity: item.quantity,
      };
      // If real Shopify variant ID exists, use it
      if (item.variantId && !item.variantId.startsWith('OSS-')) {
        lineItem.variant_id = parseInt(item.variantId);
      }
      return lineItem;
    });

    // Shipping address
    const shippingAddress = {
      first_name: firstName,
      last_name: lastName || '',
      phone: phone,
      address1: address1,
      address2: address2 || '',
      city: city,
      province: province || '',
      zip: zip || '',
      country: country || 'PK',
    };

    // Build note with payment info
    const orderNote = [
      `Payment: ${paymentMethod || 'COD'}`,
      `Delivery: ${deliveryType || 'Economy'}`,
      promoCode ? `Promo: ${promoCode}` : '',
      note || '',
    ].filter(Boolean).join(' | ');

    // Draft order payload
    const draftOrderPayload = {
      draft_order: {
        line_items: lineItems,
        shipping_address: shippingAddress,
        billing_address: shippingAddress,
        email: email || '',
        phone: phone,
        note: orderNote,
        tags: `osiss-custom-checkout, ${paymentMethod || 'cod'}`,
        use_customer_default_address: false,
      }
    };

    // Call Shopify Draft Orders API
    const shopifyRes = await fetch(
      `https://${process.env.SHOPIFY_STORE_DOMAIN}/admin/api/2024-01/draft_orders.json`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Shopify-Access-Token': process.env.SHOPIFY_ACCESS_TOKEN,
        },
        body: JSON.stringify(draftOrderPayload),
      }
    );

    const shopifyData = await shopifyRes.json();

    if (!shopifyRes.ok) {
      console.error('Shopify error:', shopifyData);
      return res.status(shopifyRes.status).json({
        error: 'Shopify order creation failed',
        details: shopifyData.errors,
      });
    }

    const draftOrder = shopifyData.draft_order;

    return res.status(200).json({
      success: true,
      orderId: draftOrder.id,
      orderNumber: draftOrder.name,        // e.g. "#D1001"
      invoiceUrl: draftOrder.invoice_url,  // Shopify payment link if needed
    });

  } catch (err) {
    console.error('Proxy error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
