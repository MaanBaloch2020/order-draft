# OSISS Shopify Proxy — Setup Guide

## Step 1: Vercel Deploy

1. GitHub pe new repo banao: `osiss-proxy`
2. Yeh 3 files upload karo:
   - `api/create-order.js`
   - `vercel.json`
   - `package.json`
3. vercel.com pe jao → "New Project" → GitHub repo select karo → Deploy

## Step 2: Environment Variables (ZAROORI!)

Vercel Dashboard → Project → Settings → Environment Variables

```
SHOPIFY_STORE_DOMAIN = osiss-7178.myshopify.com
SHOPIFY_ACCESS_TOKEN = [naya rotate kiya hua token]
```

## Step 3: Apna Vercel URL Note Karo

Deploy hone ke baad URL milega:
`https://osiss-proxy.vercel.app`

## Step 4: Theme mein Integration

`osiss.js` mein yeh karo:

1. File ke top mein add karo:
```js
const OSISS_PROXY_URL = 'https://osiss-proxy.vercel.app/api/create-order';
```

2. `OSISS-ORDER-INTEGRATION.js` ka sara code `osiss.js` ke end mein paste karo

3. COD form ke submit button mein add karo:
```html
<button id="codSubmitBtn" onclick="submitOsissOrder()">PLACE ORDER</button>
```

## Step 5: Shopify Variant IDs Add Karo

Admin → Products → koi product → Variants → ID copy karo
PRODUCTS array mein `shopifyVariantId` field add karo

## Flow Summary

Customer → Custom Form → Vercel Proxy → Shopify Draft Order ✅
No duplicate orders, no Shopify checkout redirect!
